import json
import logging
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

codebuild = boto3.client('codebuild')

def lambda_handler(event, context):
    print(event)
    project_name = event['project_name']

    try:
        response = codebuild.start_build(projectName=project_name)
        logger.info(f'Response:\n\n{response}')
    except Exception as e:
        logger.error(f'failed to start build: {e}')
        exit(e)

    return {
        'statusCode': 200,
        'body': json.dumps(f'Build started!')
    }