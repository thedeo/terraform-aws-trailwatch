import os

project_name     	= os.environ.get('PROJECT_NAME')
region           	= os.environ.get('REGION')
dashboard_domain   	= os.environ.get('DASHBOARD_DOMAIN')
static_files_domain = os.environ.get('STATIC_FILES_DOMAIN')