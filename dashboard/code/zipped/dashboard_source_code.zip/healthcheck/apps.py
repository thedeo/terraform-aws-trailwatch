from django.apps import AppConfig


class HealthcheckConfig(AppConfig):
    name = 'healthcheck'
